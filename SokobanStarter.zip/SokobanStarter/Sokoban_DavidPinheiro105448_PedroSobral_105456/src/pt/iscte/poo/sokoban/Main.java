package pt.iscte.poo.sokoban;

public class Main {

	public static void main(String[] args) {
		Engine.getInstance().start();
	}

}
