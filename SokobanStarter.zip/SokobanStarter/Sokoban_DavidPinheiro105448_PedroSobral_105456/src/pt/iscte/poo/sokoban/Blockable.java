package pt.iscte.poo.sokoban;

public interface Blockable {
	
	public TypeOfAction block();
	
}
