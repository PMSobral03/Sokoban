package pt.iscte.poo.sokoban;

public interface Obtainable {
	
	public TypeOfAction use();
	
}
